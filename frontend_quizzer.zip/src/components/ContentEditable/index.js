import ContentEditable from "./ContentEditable";
export * from "./ContentEditable";
export default ContentEditable;
