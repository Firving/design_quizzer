import Scrollbar from "./ReactPerfectScrollbar";
export * from "./ReactPerfectScrollbar";
export default Scrollbar;
