import AvatarGroup from "./AvatarGroup";
export * from "./AvatarGroup";
export default AvatarGroup;
