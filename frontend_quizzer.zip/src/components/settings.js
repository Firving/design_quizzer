const prefix = "cs";

export { prefix };
