import { prefix } from "../settings";
export const cName = `${prefix}-conversation`;
export default cName;
