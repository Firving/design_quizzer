import Loader from "./Loader";
export * from "./Loader";
export default Loader;
