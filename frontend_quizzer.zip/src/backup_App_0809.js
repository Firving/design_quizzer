import React, { Component, useState } from 'react';
import styles from '@chatscope/chat-ui-kit-styles/dist/default/styles.min.css';
// import { MainContainer, ChatContainer, MessageList, Message, MessageInput } from '@chatscope/chat-ui-kit-react';
import "./App.css";
import MainContainer from "./components/MainContainer"
// import ChatContainer from "./components/ChatContainer"
import MessageList from "./components/MessageList"
import Message from "./components/Message"
import {store, useGlobalState} from 'state-pool';  // https://github.com/yezyilomo/state-pool   Learn from here to handle globle state  https://dev.to/yezyilomo/global-state-management-in-react-with-global-variables-and-hooks-state-management-doesn-t-have-to-be-so-hard-2n2c
// import MessageInput from "./components/MessageInput"
import Image from 'rc-image';
import './index.less';
import ImgsViewer from "react-images-viewer";
import Viewer from 'react-viewer';

import {
  Dimensions,
  StyleSheet,
  View
} from 'react-native';
import { ColorWheel } from './ColorWheel';


import Wheel from './components/wheel'
import SliderBox from './components/slider-box'
import Color from 'color'
import styled from 'styled-components'


const wheelRadius = 320
const WheelHelper = styled.div`
  width: ${wheelRadius}px;
  position: relative;
`
const ColorsAmountInput = styled.input`
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  margin: auto;
  width: 56px;
  height: 40px;
  z-index: 2;
  font: inherit;
  border: 0;
  text-align: center;
  font-size: 24px;
  padding: 4px;
  color: inherit;
  appearance: none;
  z-index: 120;

  &::-webkit-inner-spin-button {
    appearance: none;
  }
`

type Mes = {
  message: String,
  isImage: Boolean,
  payload: { // if isImage = True; otherwise, this key is not existed
    src: String, //'http://zhenhuipeng.com/img/me-d.jpg', 
    alt: String, //"concepts",
    width: String //"800px"
  },
  intent: String,
  sender: String,
  sentTime: String,
  options: Array<String>,
  direction: String, //"incoming" "outgoing"
  gui: String // gui base64 data
};

type State = {
  message_list: Array<Mes>,
  cur_message: Mes,
  count: Number
};
//  let chat = createGlobalState(
const image_server = 'http://127.0.0.1:3004/'
store.setState("chat", {
  message_list: [{
      message: "DesignTutor here to help you learn UI design by criticizing design examples! To do so, I will ask you questions about the examples and give feedback. Ready?",
      isImage: false,
      //payload: {src: '', alt: '', width: ''},
      intent: "self_introduction",
      sender: "tutor",
      options: ['Got it. Let\'s go!'],
      sentTime: "just now",
      palette_url: image_server + 'test_palette.png',
      gui_url: image_server + 'test.png'
    }],
})

store.setState("uiImage", {
  imgs: [{src: 'https://i.redd.it/w8waenbekhe91.jpg', alt: ''}],
})



function useForceUpdate(){
  const [value, setValue] = useState(0); // integer state
  return () => setValue(value => value + 1); // update the state to force render
}

var changeCount = 0
var base64data = 'hehehe'
var image_content = {
  direction: "outgoing",
  payload: {
    src: base64data, 
    alt: "",
    width: "200px"
  }
}
var image_flag = false
        // window.postMessage('nativeLog', 'Called from the webview')
function randomChange() {
    document.getElementById('random_change_p').innerHTML = "The random change button was clicked. No. " + changeCount
    changeCount += 1
    console.log('button is clicked')
    window.postMessage('nativeLog', 'Request the design tutor for suggestion')
}
window.send2webui = function (data) {
    // Functions that connect to the Sketch plugin.
    // let pluginData  = JSON.parse(arg)
    // document.getElementById('random_change_p').innerHTML = data.others
    // base64data = data.base64data
    // if (!data.first_contact) {
    //   let hamrony_p = 'Type i distance: ' + data.color_harmony[0][0].toFixed(2) + ', angle: ' + data.color_harmony[1][0].toString() + "<br />" + 
    //   'Type V distance: ' + data.color_harmony[0][1].toFixed(2) + ', angle: ' + data.color_harmony[1][1].toString() + '<br />' + 
    //   'Type L distance: ' + data.color_harmony[0][2].toFixed(2) + ', angle: ' + data.color_harmony[1][2].toString() + '<br />' + 
    //   'Type L_inverse distance: ' + data.color_harmony[0][3].toFixed(2) + ', angle: ' + data.color_harmony[1][3].toString() + '<br />' + 
    //   'Type I distance: ' + data.color_harmony[0][4].toFixed(2) + ', angle: ' + data.color_harmony[1][4].toString() + '<br />' + 
    //   'Type T distance: ' + data.color_harmony[0][5].toFixed(2) + ', angle: ' + data.color_harmony[1][5].toString() + '<br />' + 
    //   'Type X distance: ' + data.color_harmony[0][6].toFixed(2) + ', angle: ' + data.color_harmony[1][6].toString() + '<br />' + 
    //   'Type Y distance: ' + data.color_harmony[0][7].toFixed(2) + ', angle: ' + data.color_harmony[1][7].toString()
    // }
    console.log('get a command from the plugin')
    let chat = store.getState("chat")
    let old_list = chat.value.message_list
    for (let i = 0; i < data.messages.length; i++) {
      old_list.push(
        {
          message: data.messages[i],
          sentTime: "just now",
          sender: "DesignTutor",
          image: false
        }
      )
    }
    if (data.change_color_flag) {
      old_list.push(
        {
          payload: {
            src: data.new_gui_url, //data.new_gui_data, 
            alt: "Suggested change",
            width: "200px"
          },
          image: true,
          sentTime: "just now",
          sender: "DesignTutor",
        }
      )
    }
    setTimeout(() => {
      chat.setValue(
        {message_list: old_list}
      )
    },
      50);
    // console.log(chat)
    // console.log(chat.value)
    return JSON.stringify({status: 'good', data: 'no data'})
}


window.updateUI = function (data) {
  // Functions that connect to the Sketch plugin.
    document.getElementById('random_change_p').innerHTML = data.success
    let color_p = ''
    let color_count = 0
    data.colors.forEach(color => {
        color_p += color_count.toString() + '. (' + color.toString() + ')[' + (data.proportion[color_count] * 100).toFixed(1) + '%]   '
        color_count += 1
    });
    document.getElementById('detected_color').innerHTML = color_p
    let hamrony_p = 'Type i distance: ' + data.color_harmony[0][0].toFixed(2) + ', angle: ' + data.color_harmony[1][0].toString() + "<br />" + 
                    'Type V distance: ' + data.color_harmony[0][1].toFixed(2) + ', angle: ' + data.color_harmony[1][1].toString() + '<br />' + 
                    'Type L distance: ' + data.color_harmony[0][2].toFixed(2) + ', angle: ' + data.color_harmony[1][2].toString() + '<br />' + 
                    'Type L_inverse distance: ' + data.color_harmony[0][3].toFixed(2) + ', angle: ' + data.color_harmony[1][3].toString() + '<br />' + 
                    'Type I distance: ' + data.color_harmony[0][4].toFixed(2) + ', angle: ' + data.color_harmony[1][4].toString() + '<br />' + 
                    'Type T distance: ' + data.color_harmony[0][5].toFixed(2) + ', angle: ' + data.color_harmony[1][5].toString() + '<br />' + 
                    'Type X distance: ' + data.color_harmony[0][6].toFixed(2) + ', angle: ' + data.color_harmony[1][6].toString() + '<br />' + 
                    'Type Y distance: ' + data.color_harmony[0][7].toFixed(2) + ', angle: ' + data.color_harmony[1][7].toString()
    document.getElementById('harmony_distance').innerHTML = hamrony_p
}


function get_GUI(index) {
  // To retrieve a GUI from the GUI server. Should be merged in the messages handled by dialog manager 
  console.log('Retrieve a GUI to ask question')
  let chat = store.getState("chat")
  let options = store.getState("options")
  let old_list = chat.value.message_list
  old_list.push(
    {
      message: "I got a new GUI example for you. Which of the following type of color harmonic template does it fit?",
      sentTime: "just now",
      sender: "DesignTutor",
      image: false
    }
  )
  let payload = {
  headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
  },
  method:'POST',
  body: {'data': index}//JSON.stringify(data)}
  };
  // document.getElementById('random_change_p').innerHTML = base64data
  var server_url = 'http://127.0.0.1:5000'
  var http = new XMLHttpRequest();
  http.open('POST', server_url, true);
  http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
  http.onreadystatechange = () => {//Call a function when the state changes.
    if (http.readyState == 4 && http.status == 200) {
      var http_response = JSON.parse(http.responseText);
      // let response_json = response.json()._value
      correct_option = http_response.correct_choice
      let gui_url = http_response.new_gui_url
      let option_list = http_response.choices
      old_list.push(
        {
          payload: {
            src: gui_url, //data.new_gui_data, 
            alt: "design example",
            width: "300px"
          },
          image: true,
          sentTime: "just now",
          sender: "DesignTutor",
        }
      )
      setTimeout(() => {
        chat.setValue(
          {message_list: old_list}
        );
        options.setValue(
          {option_list: option_list}
        )
      },
        50);
    }
  };
  http.send(encodeURIComponent(JSON.stringify({
    'data': index,
  })));

  // console.log(chat)
  // console.log(chat.value)
  return JSON.stringify({status: 'good', data: 'no data'})
}

var isPickType = false;
var isPickColor = false;
var isPickExplanation = false;
var isTutorial = true;
var tutorialStep = 0;
var gui_index = 0

function giveTutorial(step) {
  let chat = store.getState("chat")
  let options = store.getState("options")
  let old_list = chat.value.message_list
  if (step === 0) {
    old_list.push({
        message: 'Ready! Go!',
        sentTime: "just now",
        sender: "Learner",
        position: "normal",
        direction: "outgoing"
      })
      tutorialStep = 1 
      // All concepts
    old_list.push({
        message: "Here is an overview of color harmonic types that we are going to learn today. We will simply name them type i, V, L, I, and Y based on their shapes in the color wheel. You can click each type to check their details or directly go to the QAs.",
        sentTime: "just now",
        sender: "DesignTutor",
        image: false
      })
    old_list.push({
      payload: {
        src: 'http://zhenhuipeng.com/img/me-d.jpg', //data.new_gui_data, 
        alt: "concepts",
        width: "80%"
      },
      image: true,
      sentTime: "just now",
      sender: "DesignTutor",
    })
    setTimeout(() => {
      chat.setValue(
        {message_list: old_list}
      );
      options.setValue(
        {option_list: ['Type i', 'Type V', 'Type L', 'Type I', 'Type Y', 'Go to the QAs!']}
      )
    },
      50);
  }
  else if (step === 1) { 

  }
}


const concepts = [
  {
    payload: {
      src: 'http://zhenhuipeng.com/img/me-d.jpg', // 'http://127.0.0.1:8000/harmony_type_overview.png', //data.new_gui_data, 
      alt: "concepts",
      width: "500px"
    },
    image: true,
    sentTime: "just now",
    sender: "DesignTutor",
  },
]



function explainConcept(index) {
  let chat = store.getState("chat")
  let options = store.getState("options")
  let old_list = chat.value.message_list
  console.log('explainConcept')
  old_list.push({
    message: options.value.option_list[index],
    sentTime: "just now",
    sender: "Learner",
    position: "normal",
    direction: "outgoing"
  })
  if (index < 5) {
    // let example_url = 'http://127.0.0.1:8000/'
    old_list.push({
      message: "Here is an example of type i. Their colors are close to each other.", 
      sentTime: "just now",
      sender: "DesignTutor",
      image: false
    })
    old_list.push({
      payload: {
        src: 'http://zhenhuipeng.com/img/me-d.jpg', //'http://127.0.0.1:8000/type_i.png', //data.new_gui_data, 
        alt: "concepts",
        width: "800px"
      },
      image: true,
      sentTime: "just now",
      sender: "DesignTutor",
    })
    setTimeout(() => {
      chat.setValue(
        {message_list: old_list}
      )
    },
      50);
  }
  else {
    isTutorial = false
    get_GUI(gui_index)
  }
}

var correct_option = -1;
function chooseOption(index) {
  let chat = store.getState("chat")
  let options = store.getState("options")
  let old_list = chat.value.message_list
  console.log('explainConcept')
  old_list.push({
    message: options.value.option_list[index],
    sentTime: "just now",
    sender: "Learner",
    position: "normal",
    direction: "outgoing"
  })
  if (options.value.option_list[index] == 'Next Question'){
    gui_index ++
    get_GUI(gui_index)
    setTimeout(() => {
      chat.setValue(
        {message_list: old_list}
      );
    },
      50);
  }
  else if (index === correct_option) {
    old_list.push({
      message: "Good! You make a correct choice! ", 
      sentTime: "just now",
      sender: "DesignTutor",
      image: false
    })
  }
  else {
    old_list.push({
      message: "Oh, the correct choice should be " + options.value.option_list[correct_option], 
      sentTime: "just now",
      sender: "DesignTutor",
      image: false
    })
  }
  setTimeout(() => {
    chat.setValue(
      {message_list: old_list}
    );
    options.setValue(
      {option_list: ['Next Question']}
    )
  },
    50);
}

var test_tutor_message = {
  message: "Tutor\'s message",
  isImage: false,
  //payload: {src: '', alt: '', width: ''},
  intent: "tutor intent",
  sender: "tutor",
  options: ['tutor options.'],
  sentTime: "just now",
  direction: "incoming"
}
var test_user_message = {
  message: "User\'s message",
  isImage: false,
  //payload: {src: '', alt: '', width: ''},
  intent: "user intent",
  sender: "user",
  options: [],
  sentTime: "just now",
  direction: "outgoing",
  gui: ""
}

function updateMessage(message) {
  let chat = store.getState("chat")
  let old_list = chat.value.message_list
  old_list.push(message)
  setTimeout(() => {
    chat.setValue(
      {message_list: old_list}
    )
  },
    50);
}

function updateUiImage(ui_images) {
  let uiImage = store.getState("uiImage")
  setTimeout(() => {
    uiImage.setValue(
      {imgs: ui_images}
    )
    console.log(uiImage.value.imgs)
  },
    50);
}

// var imgs = [{src: 'https://i.redd.it/w8waenbekhe91.jpg', alt: ''}]
function connectServer(user_message) {
  let payload = {
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    },
    method:'POST',
    body: {'data': user_message}//JSON.stringify(data)}
  };
  // document.getElementById('random_change_p').innerHTML = base64data
  var server_url = 'http://127.0.0.1:5000' //'http://172.17.69.175:5000' //'http://127.0.0.1:5000'
  var http = new XMLHttpRequest();
  http.open('POST', server_url, true);
  http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded'); //
  http.onreadystatechange = () => {//Call a function when the state changes.
    if (http.readyState == 4 && http.status == 200) {
      var http_response = JSON.parse(http.responseText);
      console.log(http_response)
      let tutor_message = http_response.data
      for (var i = 0; i < tutor_message.length; i++) {
        updateMessage(tutor_message[i])
        // Currently can only update images with the last non-empty imgs value
        console.log(tutor_message[i].imgs)
        if (tutor_message[i].imgs.length !== 0) {
          updateUiImage(tutor_message[i].imgs)
          // console.log('HAHA')
        }
      }
      // tutor_message.map((message, index) => (
      //   updateMessage(message)
      // ))
    };
  }
  http.send(encodeURIComponent(JSON.stringify({
    'data': user_message,
    'time': '11112'
  })));
}


function App (props){
    const [chat, setChat, updateChat] = useGlobalState("chat");
    const [uiImage, setUiImage, updateUiImage] = useGlobalState("uiImage");
    var cur_message = chat.message_list[chat.message_list.length - 1]
    var imgs = uiImage.imgs
    // console.log(imgs)
    const colorsList = []
    const [ visible, setVisible ] = React.useState(false);
    return (
      <div style={{width: "90%", margin: "auto"}}> 
        <div id = 'designtutor' style={{ float: "left", position: "absolute", height: "96%", width: "40%", padding: "5px", borderStyle: "solid", borderColor: "#92a8d1"}}>        
          <div style={{ position:"relative", height: "85%"}} id = 'chat_container'>
            <MainContainer>
                  <MessageList id="main_container">
                    {chat.message_list.map((message, index) => (
                        message.isImage? 
                        <Message type="image" model={message} />
                        : 
                        <Message model={message} />
                    ))}
                  </MessageList>
            </MainContainer>
          </div> 

          <div style={{ height: "15%", width: "100%"}}>
            {
            cur_message.options.length != 0 ? 
            (
              <div className="button_container">
              {cur_message.options.map((option, index) => (
                  <button className="response_button" onClick={() => {
                    // Should customize this message
                    let user_message = { 
                      message: option,
                      isImage: false,
                      //payload: {src: '', alt: '', width: ''},
                      intent: cur_message.intent,
                      sender: "user",
                      options: [],
                      sentTime: "just now",
                      direction: "outgoing",
                      gui: ""
                    }
                    updateMessage(user_message)
                    connectServer(user_message) 
                    console.log(option)
                  }}> 
                  {option}
                  </button>
                ))}
              </div>
            ): 
            (
              null
            )
          }

            <div style={{ position:"relative", display: "inline", alignItems: "center"}}>
              <textarea
                style={{ width: '85%', marginLeft: "5px", fontSize: "16px"}}
                id="textarea"
                placeholder="Type a message or select a button ..."
                autoFocus
                rows="2"
                // value={this.text}
                // onChange={event => {this.text = event.target.value; console.log(this.text)}}
                ref={node => {
                  if (node) {
                    node.focus();
                  }
                }}
              />
              <button className="submitButton" onClick={() => {
                let user_message = { 
                  message: document.getElementById('textarea').value,
                  isImage: false,
                  //payload: {src: '', alt: '', width: ''},
                  intent: "user intent",
                  sender: "user",
                  options: [],
                  sentTime: "just now",
                  direction: "outgoing",
                  gui: "",
                  stage: "0"
                }
                updateMessage(user_message)
                connectServer(user_message) 
                // updateMessage(test_user_message)
                // updateMessage(test_tutor_message)
    
                document.getElementById('textarea').value = '';

                // // connect to Sketch plugin
                // window.send2webui('ss')
              }}> Send </button>
            </div>
          </div>
        </div>

        <div style={{ float: "right", position:"relative", height: "96%", width: "50%", padding: "5px"}}>
          <p>GUI example (click to enlarge): </p>
          {/* <ImgsViewer
            imgs={[
              { src: "https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png" },
              // { src: "http://example.com/img2.png" },
            ]}
            // currImg={this.state.currImg}
            // isOpen={this.state.viewerIsOpen}
            // onClickPrev={this.gotoPrevious}
            // onClickNext={this.gotoNext}
            // onClose={this.closeViewer}
          /> */}
          <div className='example_button'>
            {/* <button onClick={() => { setVisible(true); } }>show</button> */}
            <Viewer
              visible={visible}
              onClose={() => { setVisible(false); } }
              images={imgs}
              // images={[{src: 'https://i.redd.it/w8waenbekhe91.jpg', alt: ''}]}
            />
          </div>
          {/* <Image
            src="https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png"
            width={"100%"}
            style={{
              maxWidth: "100%", maxHeight: "100%"
            }}
            onClick={() => {
              console.log('click');
              // document.getElementById('designtutor').style.display = "None"
            }}
          /> */}
          <button className='example_button' onClick={() => {
              setVisible(true)
              console.log('enlarge UI example')
              }}>
              <img id='ui_example' src={imgs[0].src} style={{maxWidth: "100%", maxHeight: "100%", margin: "auto", top: "50%", left: "50%"}} />
          </button>
        </div>
    </div>
    );
  }

export default App;

