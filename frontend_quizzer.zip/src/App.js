import React, { Component, useState } from 'react';
import styles from '@chatscope/chat-ui-kit-styles/dist/default/styles.min.css';
// import { MainContainer, ChatContainer, MessageList, Message, MessageInput } from '@chatscope/chat-ui-kit-react';
import "./App.css";
import MainContainer from "./components/MainContainer"
// import ChatContainer from "./components/ChatContainer"
import MessageList from "./components/MessageList"
import Message from "./components/Message"
import {store, useGlobalState} from 'state-pool';  // https://github.com/yezyilomo/state-pool   Learn from here to handle globle state  https://dev.to/yezyilomo/global-state-management-in-react-with-global-variables-and-hooks-state-management-doesn-t-have-to-be-so-hard-2n2c
// import MessageInput from "./components/MessageInput"
import Image from 'rc-image';
import './index.less';
import ImgsViewer from "react-images-viewer";
import Viewer from 'react-viewer';

import {
  Dimensions,
  StyleSheet,
  View
} from 'react-native';
import { ColorWheel } from './ColorWheel';


import Wheel from './components/wheel'
import SliderBox from './components/slider-box'
import Color from 'color'
import styled from 'styled-components'


const wheelRadius = 320
const WheelHelper = styled.div`
  width: ${wheelRadius}px;
  position: relative;
`
const ColorsAmountInput = styled.input`
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  margin: auto;
  width: 56px;
  height: 40px;
  z-index: 2;
  font: inherit;
  border: 0;
  text-align: center;
  font-size: 24px;
  padding: 4px;
  color: inherit;
  appearance: none;
  z-index: 120;

  &::-webkit-inner-spin-button {
    appearance: none;
  }
`

type Mes = {
  message: String, // user input
  tutor_message: String,
  isImage: Boolean,
  payload: { // if isImage = True; otherwise, this key is not existed
    src: String, //'http://zhenhuipeng.com/img/me-d.jpg', 
    alt: String, //"concepts",
    width: String //"800px"
  },
  state: String,
  sender: String,
  sentTime: String,
  options: Array<String>,
  direction: String, //"incoming" "outgoing"
  gui: String, // gui base64 data
  post_id: Number,
  explanation: String,
  cloze_test: String,
  multiple_choices: Array<String>
};

type State = {
  message_list: Array<Mes>,
  cur_message: Mes,
  count: Number
};
//  let chat = createGlobalState(
const image_server = 'http://127.0.0.1:3004/'
store.setState("chat", {
  message_list: [{
      message:  'Hi, I am <b>DesingQuizzer</b>. Today, I will help you familiarize yourself with visual design elements about color and typography).',//"<b>DesignTutor here to help you familiarize design elements through UI examples! </b> To do so, I will ask you multiple-choices questions about the critique on UI examples. Ready?",
      isImage: false,
      //payload: {src: '', alt: '', width: ''},
      state: "state of the dialog flow",
      sender: "tutor",
      options: ['Cool, but how?'],
      sentTime: "just now",
      palette_url: image_server + 'test_palette.png',
      gui_url: image_server + 'test.png',
      state: '0',
      tutor_message: '',
      user_message: '',
      post_id: -1,
      explanation: '',
      cloze_test: '',
      imgs: [],
      correct_answer: '',
      user_id: '',
      multiple_choices: [],
      mention_ui_elements: [],
      wiki: []
    }],
})

store.setState("uiImage", {
  imgs: [{src: 'https://i.redd.it/w8waenbekhe91.jpg', alt: ''}],
})



function useForceUpdate(){
  const [value, setValue] = useState(0); // integer state
  return () => setValue(value => value + 1); // update the state to force render
}

var changeCount = 0
var base64data = 'hehehe'
var image_content = {
  direction: "outgoing",
  payload: {
    src: base64data, 
    alt: "",
    width: "200px"
  }
}
var image_flag = false
        // window.postMessage('nativeLog', 'Called from the webview')
function randomChange() {
    document.getElementById('random_change_p').innerHTML = "The random change button was clicked. No. " + changeCount
    changeCount += 1
    console.log('button is clicked')
    window.postMessage('nativeLog', 'Request the design tutor for suggestion')
}
window.send2webui = function (data) {
    // Functions that connect to the Sketch plugin.
    // let pluginData  = JSON.parse(arg)
    // document.getElementById('random_change_p').innerHTML = data.others
    // base64data = data.base64data
    // if (!data.first_contact) {
    //   let hamrony_p = 'Type i distance: ' + data.color_harmony[0][0].toFixed(2) + ', angle: ' + data.color_harmony[1][0].toString() + "<br />" + 
    //   'Type V distance: ' + data.color_harmony[0][1].toFixed(2) + ', angle: ' + data.color_harmony[1][1].toString() + '<br />' + 
    //   'Type L distance: ' + data.color_harmony[0][2].toFixed(2) + ', angle: ' + data.color_harmony[1][2].toString() + '<br />' + 
    //   'Type L_inverse distance: ' + data.color_harmony[0][3].toFixed(2) + ', angle: ' + data.color_harmony[1][3].toString() + '<br />' + 
    //   'Type I distance: ' + data.color_harmony[0][4].toFixed(2) + ', angle: ' + data.color_harmony[1][4].toString() + '<br />' + 
    //   'Type T distance: ' + data.color_harmony[0][5].toFixed(2) + ', angle: ' + data.color_harmony[1][5].toString() + '<br />' + 
    //   'Type X distance: ' + data.color_harmony[0][6].toFixed(2) + ', angle: ' + data.color_harmony[1][6].toString() + '<br />' + 
    //   'Type Y distance: ' + data.color_harmony[0][7].toFixed(2) + ', angle: ' + data.color_harmony[1][7].toString()
    // }
    console.log('get a command from the plugin')
    let chat = store.getState("chat")
    let old_list = chat.value.message_list
    for (let i = 0; i < data.messages.length; i++) {
      old_list.push(
        {
          message: data.messages[i],
          sentTime: "just now",
          sender: "DesignTutor",
          image: false
        }
      )
    }
    if (data.change_color_flag) {
      old_list.push(
        {
          payload: {
            src: data.new_gui_url, //data.new_gui_data, 
            alt: "Suggested change",
            width: "200px"
          },
          image: true,
          sentTime: "just now",
          sender: "DesignTutor",
        }
      )
    }
    setTimeout(() => {
      chat.setValue(
        {message_list: old_list}
      )
    },
      50);
    // console.log(chat)
    // console.log(chat.value)
    return JSON.stringify({status: 'good', data: 'no data'})
}



window.updateUI = function (data) {
  // Functions that connect to the Sketch plugin.
    document.getElementById('random_change_p').innerHTML = data.success
    let color_p = ''
    let color_count = 0
    data.colors.forEach(color => {
        color_p += color_count.toString() + '. (' + color.toString() + ')[' + (data.proportion[color_count] * 100).toFixed(1) + '%]   '
        color_count += 1
    });
    document.getElementById('detected_color').innerHTML = color_p
    let hamrony_p = 'Type i distance: ' + data.color_harmony[0][0].toFixed(2) + ', angle: ' + data.color_harmony[1][0].toString() + "<br />" + 
                    'Type V distance: ' + data.color_harmony[0][1].toFixed(2) + ', angle: ' + data.color_harmony[1][1].toString() + '<br />' + 
                    'Type L distance: ' + data.color_harmony[0][2].toFixed(2) + ', angle: ' + data.color_harmony[1][2].toString() + '<br />' + 
                    'Type L_inverse distance: ' + data.color_harmony[0][3].toFixed(2) + ', angle: ' + data.color_harmony[1][3].toString() + '<br />' + 
                    'Type I distance: ' + data.color_harmony[0][4].toFixed(2) + ', angle: ' + data.color_harmony[1][4].toString() + '<br />' + 
                    'Type T distance: ' + data.color_harmony[0][5].toFixed(2) + ', angle: ' + data.color_harmony[1][5].toString() + '<br />' + 
                    'Type X distance: ' + data.color_harmony[0][6].toFixed(2) + ', angle: ' + data.color_harmony[1][6].toString() + '<br />' + 
                    'Type Y distance: ' + data.color_harmony[0][7].toFixed(2) + ', angle: ' + data.color_harmony[1][7].toString()
    document.getElementById('harmony_distance').innerHTML = hamrony_p
}


function updateMessage(message) {
  let chat = store.getState("chat")
  let old_list = chat.value.message_list
  old_list.push(message)
  setTimeout(() => {
    chat.setValue(
      {message_list: old_list}
    )
  },
    50);
}

function updateUiImage(ui_images) {
  let uiImage = store.getState("uiImage")
  setTimeout(() => {
    uiImage.setValue(
      {imgs: ui_images}
    )
    console.log(uiImage.value.imgs)
  },
    50);
}

// var imgs = [{src: 'https://i.redd.it/w8waenbekhe91.jpg', alt: ''}]
function connectServer(user_message) {
  let payload = {
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    },
    method:'POST',
    body: {'data': user_message}//JSON.stringify(data)}
  };
  // document.getElementById('random_change_p').innerHTML = base64data
  var server_url = 'http://127.0.0.1:5000' //'http://172.17.69.175:5000' //'http://127.0.0.1:5000'
  var http = new XMLHttpRequest();
  http.open('POST', server_url, true);
  http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded'); //
  http.onreadystatechange = () => {//Call a function when the state changes.
    if (http.readyState == 4 && http.status == 200) {
      var http_response = JSON.parse(http.responseText);
      console.log(http_response)
      let tutor_message = http_response.data
      for (var i = 0; i < tutor_message.length; i++) {
        tutor_message[i]['message'] = tutor_message[i].tutor_message
        updateMessage(tutor_message[i])
        // Currently can only update images with the last non-empty imgs value
        // console.log(tutor_message[i].imgs)
        if (tutor_message[i].imgs.length !== 0) {
          updateUiImage(tutor_message[i].imgs)
          document.getElementById('post_title').innerHTML = tutor_message[i].post_title
          document.getElementById('post_body').innerHTML = tutor_message[i].post_body
          // console.log('HAHA')
        }
        document.getElementById('performance').innerHTML = '(Correct) ' + tutor_message[i].correct + ' / ' + tutor_message[i].total + ' (Total)'
        if (tutor_message[i].state == 'Query UI Component' || tutor_message[i].state == 'Query Visual Element'){
          console.log('set textarea')
          document.getElementById('textarea').disabled = false
        }
        else{
          document.getElementById('textarea').disabled = true
        }
      }
      
    };
  }
  http.send(encodeURIComponent(JSON.stringify({
    'data': user_message,
    'time': '11112'
  })));
}


function App (props){
    const [chat, setChat, updateChat] = useGlobalState("chat");
    const [uiImage, setUiImage, updateUiImage] = useGlobalState("uiImage");
    var cur_message = chat.message_list[chat.message_list.length - 1]
    var imgs = uiImage.imgs
    // console.log(imgs)
    const colorsList = []
    const [ visible, setVisible ] = React.useState(false);
    return (
      <div style={{width: "90%", margin: "auto"}}> 
        <div id = 'designtutor' style={{ float: "left", position: "absolute", height: "96%", width: "40%", padding: "5px", borderStyle: "solid", borderColor: "#92a8d1"}}>        
          <div style={{ position:"relative", height: "94%"}} id = 'chat_container'>
            <MainContainer>
                  <MessageList id="main_container">
                    {chat.message_list.map((message, index) => (
                        
                        <div>
                          {message.isImage? 
                            (<Message type="image" model={message} />)
                            : 
                            (<Message model={message} />)
                          }
                          {
                          cur_message.message == message.message ? 
                          (
                            <div className="button_container">
                            {cur_message.options.map((option, index) => (
                              
                                (option == "I need a hint." || option == "Cool, but how?" || option == "No, I\'ll try again." || option == "I don\'t know." || option == "Next Question!" || option == "Got it. Let\'s go!" || option == "Yes, answer please." || option == "Why?" || option == "Wait, I got it right!" || option == "Wait, it\'s not necessary right!" || option == "I want to explore an UI element." || option == "I want to explore a design element.") ?
                                (
                                  <button className="other_response_button" onClick={() => {
                                    // Should customize this message
                                    let user_message = { 
                                      message: option,
                                      tutor_message: cur_message.tutor_message,
                                      correct_answer: cur_message.correct_answer,
                                      user_id: cur_message.user_id,
                                      imgs: cur_message.imgs,
                                      post_id: cur_message.post_id,
                                      explanation: cur_message.explanation,
                                      cloze_test: cur_message.cloze_test,
                                      multiple_choices: cur_message.multiple_choices,
                                      mention_ui_elements: cur_message.mention_ui_elements,
                                      wiki: cur_message.wiki,
                                      isImage: false,
                                      state: cur_message.state,
                                      sender: "user",
                                      options: [],
                                      sentTime: "just now",
                                      direction: "outgoing",
                                      hint: cur_message.hint,
                                      answer_cluster: cur_message.answer_cluster,
                                      post_title: cur_message.post_title,
                                      post_body: cur_message.post_body,
                                      user_id: cur_message.user_id,
                                      correct: cur_message.correct,
                                      total: cur_message.total,
                                      post_id: cur_message.post_id,
                                      question_id: cur_message.question_id
                                    }
                                    console.log(user_message)
                                    updateMessage(user_message)
                                    connectServer(user_message) 
                                    console.log(option)
                                  }}> 
                                  {option}
                                  </button>
                                )
                                :
                                (
                                <button className="response_button" onClick={() => {
                                  // Should customize this message
                                  let user_message = { 
                                    message: option,
                                    tutor_message: cur_message.tutor_message,
                                    correct_answer: cur_message.correct_answer,
                                    user_id: cur_message.user_id,
                                    imgs: cur_message.imgs,
                                    post_id: cur_message.post_id,
                                    explanation: cur_message.explanation,
                                    cloze_test: cur_message.cloze_test,
                                    multiple_choices: cur_message.multiple_choices,
                                    mention_ui_elements: cur_message.mention_ui_elements,
                                    wiki: cur_message.wiki,
                                    isImage: false,
                                    state: cur_message.state,
                                    sender: "user",
                                    options: [],
                                    sentTime: "just now",
                                    direction: "outgoing",
                                    hint: cur_message.hint,
                                    answer_cluster: cur_message.answer_cluster,
                                    post_title: cur_message.post_title,
                                    post_body: cur_message.post_body,
                                    user_id: cur_message.user_id,
                                    correct: cur_message.correct,
                                    total: cur_message.total,
                                    post_id: cur_message.post_id,
                                    question_id: cur_message.question_id
                                  }
                                  console.log(user_message)
                                  updateMessage(user_message)
                                  connectServer(user_message) 
                                  console.log(option)
                                }}> 
                                {option}
                                </button>
                                )
                              
                              ))}
                            </div>
                          ): 
                          (
                            <div className="button_container">
                            {message.options.map((option, index) => (
                                <button className="response_button_old" disabled={true}>
                                  {option}
                                </button>
                            ))}
                            </div>
                          )
                        }
                        </div>
                        
                    ))}
                    
                  </MessageList>
            </MainContainer>
          </div> 

          <div style={{ height: "5%", width: "100%", marginTop: "1%"}}>
            {/* {
            cur_message.options.length != 0 ? 
            (
              <div className="button_container">
              {cur_message.options.map((option, index) => (
                  <button className="response_button" onClick={() => {
                    // Should customize this message
                    let user_message = { 
                      message: option,
                      tutor_message: cur_message.tutor_message,
                      correct_answer: cur_message.correct_answer,
                      user_id: cur_message.user_id,
                      imgs: cur_message.imgs,
                      post_id: cur_message.post_id,
                      explanation: cur_message.explanation,
                      cloze_test: cur_message.cloze_test,
                      multiple_choices: cur_message.multiple_choices,
                      mention_ui_elements: cur_message.mention_ui_elements,
                      wiki: cur_message.wiki,
                      isImage: false,
                      state: cur_message.state,
                      sender: "user",
                      options: [],
                      sentTime: "just now",
                      direction: "outgoing",
                      hint: cur_message.hint,
                      answer_cluster: cur_message.answer_cluster,
                      post_title: cur_message.post_title,
                      post_body: cur_message.post_body
                    }
                    console.log(user_message)
                    updateMessage(user_message)
                    connectServer(user_message) 
                    console.log(option)
                  }}> 
                  {option}
                  </button>
                ))}
              </div>
            ): 
            (
              null
            )
          } */}

            <div style={{ position:"relative", display: "inline", alignItems: "center"}}>
              <textarea
                style={{ width: '85%', marginLeft: "5px", fontSize: "16px"}}
                id="textarea"
                placeholder="Select a button or type your message if needed..."
                autoFocus
                rows="2"
                disabled="true"
                // value={this.text}
                // onChange={event => {this.text = event.target.value; console.log(this.text)}}
                ref={node => {
                  if (node) {
                    node.focus();
                  }
                }}
              />
              <button className="submitButton" onClick={() => {
                let user_message = { 
                  message: document.getElementById('textarea').value,
                  tutor_message: cur_message.tutor_message,
                  correct_answer: cur_message.correct_answer,
                  user_id: cur_message.user_id,
                  imgs: cur_message.imgs,
                  post_id: cur_message.post_id,
                  explanation: cur_message.explanation,
                  cloze_test: cur_message.cloze_test,
                  multiple_choices: cur_message.multiple_choices,
                  mention_ui_elements: cur_message.mention_ui_elements,
                  wiki: cur_message.wiki,
                  isImage: false,
                  //payload: {src: '', alt: '', width: ''},
                  state: cur_message.state,
                  sender: "user",
                  options: [],
                  sentTime: "just now",
                  direction: "outgoing",
                  hint: cur_message.hint,
                  answer_cluster: cur_message.answer_cluster,
                  post_title: cur_message.post_title,
                  post_body: cur_message.post_body,
                  user_id: cur_message.user_id,
                  correct: cur_message.correct,
                  total: cur_message.total,
                  post_id: cur_message.post_id,
                  question_id: cur_message.question_id
                }
                updateMessage(user_message)
                connectServer(user_message) 
                document.getElementById('textarea').value = '';

                // // connect to Sketch plugin
                // window.send2webui('ss')
              }}> Send </button>
            </div>
          </div>
        </div>

        <div style={{ float: "right", position:"relative", height: "96%", width: "50%", padding: "5px"}}>
          <div style={{position:"relative", width: "100%", padding: "5px"}}>
            <div style={{float: "left", position:"relative", width: "48%", padding: "5px"}}>
              <h3 id='post_title'>Post title here</h3>
              <p id='post_body'>The post body here</p>
              <p>GUI example (click to enlarge): </p>
            </div>
            <div style={{float: "right", position:"relative", width: "38%", padding: "5px"}}>
              <h3 id='progress_bar'>Your Quiz Result: </h3>
              <h4 id='performance'>(Correct) 0 / 0 (Total)</h4>
            </div>
          </div>
          <div className='example_button'>
            <Viewer
              visible={visible}
              onClose={() => { setVisible(false); } }
              images={imgs}
              // images={[{src: 'https://i.redd.it/w8waenbekhe91.jpg', alt: ''}]}
            />
          </div>
          <button className='example_button' onClick={() => {
              setVisible(true)
              console.log('enlarge UI example')
              }}>
              <img id='ui_example' src={imgs[0].src} style={{maxWidth: "100%", maxHeight: "100%", margin: "auto", top: "50%", left: "50%"}} />
          </button>
        </div>
    </div>
    );
  }

export default App;

