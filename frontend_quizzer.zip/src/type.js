export type Mes = {
  message: String,
  sentTime: String,
  sender: String
};

export type State = {
  message_list: Array<Mes>,
  cur_message: Mes,
  count: Number
};