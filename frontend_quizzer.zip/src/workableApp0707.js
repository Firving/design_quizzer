// import React, { Component, useState } from 'react';
// import styles from '@chatscope/chat-ui-kit-styles/dist/default/styles.min.css';
// // import { MainContainer, ChatContainer, MessageList, Message, MessageInput } from '@chatscope/chat-ui-kit-react';
// import "./App.css";
// import MainContainer from "./components/MainContainer"
// // import ChatContainer from "./components/ChatContainer"
// import MessageList from "./components/MessageList"
// import Message from "./components/Message"
// // import MessageInput from "./components/MessageInput"

// type Mes = {
//   message: String,
//   sentTime: String,
//   sender: String
// };

// type State = {
//   message_list: Array<Mes>,
//   cur_message: Mes,
//   count: Number
// };

// var state = {
//   message_list: [{
//       message: "Hello my friend",
//       sentTime: "just now",
//       sender: "DesignTutor"
//     }, 
//     {
//       message: "Hello!",
//       sentTime: "just now",
//       direction: "outgoing",
//       position: "normal",
//       sender: "Learner"
//     }],
//   cur_message: {
//     message: 'test message',
//     sentTime: 'just now',
//     sender: 'DesignTutor'
//   },
//   count: 0
// }
// function useForceUpdate(){
//   const [value, setValue] = useState(0); // integer state
//   return () => setValue(value => value + 1); // update the state to force render
// }

// var changeCount = 0
// var base64data = 'hehehe'
//         // window.postMessage('nativeLog', 'Called from the webview')
// function randomChange() {
//     document.getElementById('random_change_p').innerHTML = "The random change button was clicked. No. " + changeCount
//     changeCount += 1
//     console.log('button is clicked')
//     window.postMessage('nativeLog', 'Request the design tutor for suggestion')
// }
// window.send2webui = function (data) {
//     // let pluginData  = JSON.parse(arg)
//     // document.getElementById('random_change_p').innerHTML = data.others
//     // base64data = data.base64data
//     console.log('get a command from the plugin')
//     // const {message_list} = this.state;
//     // this.setState({message_list: [...message_list, {
//     //   message: 'message from DesignTutor',
//     //   sentTime: "just now",
//     //   sender: "DesignTutor",
//     // }]})
//     // console.log(message_list)
//     // update message from DesignTutor should be parsed from the data
//     state.message_list.push({
//       message: 'message from DesignTutor',
//       sentTime: "just now",
//       sender: "DesignTutor"
//     })
//     console.log('nothing?')
//     // const forceUpdate = useForceUpdate();
//     // setState
//     return JSON.stringify({status: 'good', data: 'no data'})
// }



// window.updateUI = function (data) {
//     document.getElementById('random_change_p').innerHTML = data.success
//     let color_p = ''
//     let color_count = 0
//     data.colors.forEach(color => {
//         color_p += color_count.toString() + '. (' + color.toString() + ')[' + (data.proportion[color_count] * 100).toFixed(1) + '%]   '
//         color_count += 1
//     });
//     document.getElementById('detected_color').innerHTML = color_p
//     let hamrony_p = 'Type i distance: ' + data.color_harmony[0][0].toFixed(2) + ', angle: ' + data.color_harmony[1][0].toString() + "<br />" + 
//                     'Type V distance: ' + data.color_harmony[0][1].toFixed(2) + ', angle: ' + data.color_harmony[1][1].toString() + '<br />' + 
//                     'Type L distance: ' + data.color_harmony[0][2].toFixed(2) + ', angle: ' + data.color_harmony[1][2].toString() + '<br />' + 
//                     'Type L_inverse distance: ' + data.color_harmony[0][3].toFixed(2) + ', angle: ' + data.color_harmony[1][3].toString() + '<br />' + 
//                     'Type I distance: ' + data.color_harmony[0][4].toFixed(2) + ', angle: ' + data.color_harmony[1][4].toString() + '<br />' + 
//                     'Type T distance: ' + data.color_harmony[0][5].toFixed(2) + ', angle: ' + data.color_harmony[1][5].toString() + '<br />' + 
//                     'Type X distance: ' + data.color_harmony[0][6].toFixed(2) + ', angle: ' + data.color_harmony[1][6].toString() + '<br />' + 
//                     'Type Y distance: ' + data.color_harmony[0][7].toFixed(2) + ', angle: ' + data.color_harmony[1][7].toString()
//     document.getElementById('harmony_distance').innerHTML = hamrony_p
// }

// class App extends Component <State>{
//   state = {
//     message_list: [{
//         message: "Hello my friend",
//         sentTime: "just now",
//         sender: "DesignTutor"
//       }, 
//       {
//         message: "Hello!",
//         sentTime: "just now",
//         direction: "outgoing",
//         position: "normal",
//         sender: "Learner"
//       }],
//     cur_message: {
//       message: 'test message',
//       sentTime: 'just now',
//       sender: 'DesignTutor'
//     },
//     count: 0
//   }

//   send2webui = window.send2webui.bind(this)
//   state: State;
//   text = '';
//   render() {
//     return (
//       <div style={{ position:"fixed", height: "80%", width: "60%" }}>
//       <MainContainer>
//         {/* <ChatContainer>        */}
//           <MessageList>
//             {this.state.message_list.map((message, index) => (
//               <Message model={message} />
//             ))}
//             </MessageList>
//           {/* <MessageInput placeholder="Type message here" 
//                         onSend={sendMessage => {
//                           console.log("send a message")
//                           console.log(sendMessage)
//                           const {message_list, count} = this.state;
//                           let temp_count = count
//                           this.setState({
//                             message_list: [...message_list, {
//                               message: sendMessage,
//                               sentTime: "just now",
//                               sender: "Learner",
//                               position: "normal",
//                               direction: "outgoing"
//                             }],
//                             count: temp_count++
//                           })
//                           console.log(message_list)
//                         }} 
//                         attachButton={false}
//           />         */}
//         {/* </ChatContainer> */}
//       </MainContainer>
//         <div>
//           <textarea
//             // , 'line-height': '1', 'font-size': '14px'
//             style={{ width: '80%' }}
//             id="textarea"
//             placeholder="Input your critical thinking ..."
//             autoFocus
//             rows="4"
//             // value={this.text}
//             // onChange={event => {this.text = event.target.value; console.log(this.text)}}
//             ref={node => {
//               if (node) {
//                 node.focus();
//               }
//             }}
//           />
//           <button className="submitButton" onClick={() => {
//             const {message_list, count} = this.state;
//             this.setState({
//               message_list: [...message_list, {
//                 message: document.getElementById('textarea').value,
//                 sentTime: "just now",
//                 sender: "Learner",
//                 position: "normal",
//                 direction: "outgoing"
//               }]})
//             state.message_list.push({
//               message: document.getElementById('textarea').value,
//               sentTime: "just now",
//               sender: "Learner",
//               position: "normal",
//               direction: "outgoing"
//             })
//             console.log(document.getElementById('textarea').value)
//             document.getElementById('textarea').value = ''
//             console.log(this.state.message_list)
//             console.log('a send button is clicked')
//             window.postMessage('nativeLog', 'Request the React design tutor for suggestion')  //used only in the plugin...
//             setTimeout(() => {
//               console.log('update message from DesignTutor?')
//               this.setState({
//                 message_list: state.message_list})
//               // this.send2webui('ddd')
//             },
//               1000); // 这是有点骚的方法了。。。因为看起来：sketch plugin 没法去调用react component里的function，外部的function也没办法update react component里的function
//           }}> Send </button>
//         </div>
//       </div>
//     );
//   }
// }

// export default App;

